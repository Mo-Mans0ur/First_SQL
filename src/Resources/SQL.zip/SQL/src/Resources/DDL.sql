CREATE TABLE imdb-data (
Year varChar(255), 
Length varChar(255), 
Title varChar(255), 
Subject varChar(255), 
Popularity varChar(255), 
Awards varChar(255), 
);CREATE TABLE imdb-data (
Year varChar(255), 
Length varChar(255), 
Title varChar(255), 
Subject varChar(255), 
Popularity varChar(255), 
Awards varChar(255), 
);CREATE TABLE imdb-data (
Year varChar(255), 
Length varChar(255), 
Title varChar(255), 
Subject varChar(255), 
Popularity varChar(255), 
Awards varChar(255), 
);
CREATE TABLE imdb-data (
Year varChar(255), 
Length varChar(255), 
Title varChar(255), 
Subject varChar(255), 
Popularity varChar(255), 
Awards varChar(255), 
);
CREATE TABLE imdb-data (
Year varChar(255), 
Length varChar(255), 
Title varChar(255), 
Subject varChar(255), 
Popularity varChar(255), 
Awards varChar(255), 
);

CREATE TABLE imdb-data (
Year varChar(255), 
Length varChar(255), 
Title varChar(255), 
Subject varChar(255), 
Popularity varChar(255), 
Awards varChar(255), 
);

CREATE TABLE imdb-data (
Year varChar(255), 
Length varChar(255), 
Title varChar(255), 
Subject varChar(255), 
Popularity varChar(255), 
Awards varChar(255), 
);

